import requests

#loc-if str returns street name and if sub returns subcity
def get_street_and_subcity(lat, lon, loca):
    url = "https://nominatim.openstreetmap.org/reverse"
    params = {
        "lat": lat,
        "lon": lon,
        "format": "json",
        "addressdetails": 1,
        "accept-language": "en"  
    }
    headers = {
        "User-Agent": "CCMS-App"
    }

    response = requests.get(url, params=params, headers=headers)
    data = response.json()
    address = data.get("address", {})

    street = address.get("road") or address.get("residential") or address.get("pedestrian")
    subcity = address.get("suburb") or address.get("city_district")

    if loca == "str":
        if street != None:
            return f"{street}"
        else:
            return f"No Street Name"
    elif loca == "sub":
        if subcity != None:
            return f"{subcity}"
        else:
            return f"No Subcity Name"
    else:
        return f"Error"

result = get_street_and_subcity(9.025403, 38.796283,"sub")
print(result)

