from flask import Blueprint, render_template, url_for, redirect, request, flash, current_app
from .forms import ComplaintForm
from .models import Report, db, News, Comment, Like
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from flask_login import current_user, login_required

routes_bp = Blueprint("routes_bp", __name__, url_prefix="/ccms")

# Configuration
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}
MAX_CONTENT_LENGTH = 5 * 1024 * 1024  # 5MB max file size

def allowed_file(filename):
    
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def save_uploaded_file(file):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        upload_folder = os.path.join(current_app.root_path, 'static', 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        filepath = os.path.join(upload_folder, filename)
        file.save(filepath)
        return f"uploads/{filename}"  # Return relative path
    return None

@routes_bp.route("/")
def welcome():
    return render_template("Welcome.html")

@routes_bp.route("/home", methods=["GET", "POST"])

def home():
    try:
        all_news = News.query.all()
        page = request.args.get('page', 1, type=int)
        per_page = 10
        query = Report.query.options(
            db.joinedload(Report.comments),  
            db.joinedload(Report.likes) 
        ).order_by(Report.createdAt.desc())
        
        category_filter = request.args.get('filter', 'all')
        if category_filter and category_filter.lower() != 'all':
            query = query.filter(Report.category.ilike(f"%{category_filter}%"))

        paginated_reports = query.paginate(page=page, per_page=per_page, error_out=False)

        for report in paginated_reports.items:
            report.comments.sort(key=lambda c: c.createdAt, reverse=True)

        print("All reports in DB:", [(r.id, r.category) for r in query.all()])
        for report in paginated_reports.items:
            print(f"Report {report.id}: {len(report.comments)} comments, {len(report.likes)} likes")
        
        return render_template(
            "home.html",
            complaints=paginated_reports.items,
            pagination=paginated_reports,
            all_news=all_news,
            categories=db.session.query(Report.category.distinct()).all(),
            current_filter=category_filter
        )

    except Exception as e:
        print("Error:", str(e))
        flash("An error occurred while loading complaints.", "danger")
        return render_template(
            "home.html",
            complaints=[],
            pagination=None,
            all_news=[],
            categories=[],
            current_filter='all'
        )

@routes_bp.route("/like/<int:report_id>", methods=["POST"])
@login_required
def like_report(report_id):
    existing_like = Like.query.filter_by(report_id=report_id, user_id=current_user.id).first()
    if not existing_like:
        new_like = Like(report_id=report_id, user_id=current_user.id)
        db.session.add(new_like)
        db.session.commit()
        flash("You liked the report.", "success")
    else:
        flash("You already liked this report.", "info")
    
    return redirect(request.referrer or url_for('home'))


@routes_bp.route("/comment/<int:report_id>", methods=["POST"])
@login_required
def add_comment(report_id):
    content = request.form.get("comment")
    if content:
        new_comment = Comment(content=content, report_id=report_id, user_id=current_user.id)
        db.session.add(new_comment)
        db.session.commit()
        flash("Comment added successfully!", "success")
    else:
        flash("Comment cannot be empty.", "danger")

    return redirect(url_for('routes_bp.home'))


@routes_bp.route("/aboutUs")
def aboutUs():
    return render_template("aboutUs.html")

@routes_bp.route("/myComplaint")
@login_required
def myComplaint():
  
    reports = Report.query.filter_by(user_id=current_user.id).order_by(Report.createdAt.desc()).all()
    return render_template("myComplaint.html", reports=reports)

@routes_bp.route("/submit", methods=["GET", "POST"])
@login_required
def submit():
    form = ComplaintForm()
    
    if form.validate_on_submit():
        try:
            current_app.logger.debug(f"Form data: {form.data}")

            image_path = None
            if form.image.data:
                current_app.logger.debug("Image file detected")
                image_path = save_uploaded_file(form.image.data)
                if not image_path:
                    flash("Invalid image file. Only PNG, JPG, JPEG, GIF allowed.", "danger")
                    return redirect(url_for("routes_bp.submit"))
                current_app.logger.debug(f"Image saved to: {image_path}")
            new_report = Report(
                category=form.category.data,
                description=form.description.data,
                latitude=float(form.latitude.data),  
                longitude=float(form.longitude.data), 
                image=image_path if image_path else "default.jpg",
                user_id=current_user.id,
                status="ongoing",
                createdAt=datetime.utcnow()
            )
            
            current_app.logger.debug(f"New report object: {new_report.__dict__}")

            # Add to session and commit
            db.session.add(new_report)
            db.session.commit()
            current_app.logger.debug("Report successfully committed to database")
            
            flash("Report submitted successfully!", "success")
            return redirect(url_for("routes_bp.submit"))
            
        except ValueError as ve:
            db.session.rollback()
            current_app.logger.error(f"ValueError in submit: {str(ve)}")
            flash("Invalid location coordinates. Please select a valid location on the map.", "danger")
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error submitting report: {str(e)}", exc_info=True)
            flash("An error occurred while submitting your report. Please try again.", "danger")
    

    if form.errors:
        current_app.logger.debug(f"Form errors: {form.errors}")
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", "danger")
    
    return render_template("submit.html", form=form)



@routes_bp.route("/report/<int:report_id>")
def view_report(report_id):
    report = Report.query.get_or_404(report_id)
    # Ensure the current user owns this report
    # if report.user_id != current_user.id:
    
    
    return render_template("view_report.html", report=report)



@routes_bp.route("/report/<int:report_id>/update", methods=["GET", "POST"])
@login_required
def update_report(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id:
        flash("You don't have permission to update this report", "danger")
        return redirect(url_for("routes_bp.myComplaint"))
    
    form = ComplaintForm(obj=report)
    
    if form.validate_on_submit():
        try:
            report.category = form.category.data
            report.description = form.description.data
            report.latitude = form.latitude.data
            report.longitude = form.longitude.data
            
            if form.image.data:
                # Delete old image if it exists and isn't the default
                if report.image and report.image != "default.jpg":
                    old_image_path = os.path.join(current_app.root_path, 'static', report.image)
                    if os.path.exists(old_image_path):
                        os.remove(old_image_path)
                
                # Save new image
                image_path = save_uploaded_file(form.image.data)
                if image_path:
                    report.image = image_path
            
            db.session.commit()
            flash("Report updated successfully!", "success")
            return redirect(url_for("routes_bp.view_report", report_id=report.id))
            
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error updating report: {str(e)}")
            flash("An error occurred while updating your report. Please try again.", "danger")
    
    return render_template("update_report.html", form=form, report=report)



@routes_bp.route("/report/<int:report_id>/delete", methods=["POST"])
@login_required
def delete_report(report_id):
    report = Report.query.get_or_404(report_id)
    if report.user_id != current_user.id:
        flash("You don't have permission to delete this report", "danger")
        return redirect(url_for("routes_bp.myComplaint"))
    
    try:
        # Delete associated image file if it exists and isn't the default
        if report.image and report.image != "default.jpg":
            image_path = os.path.join(current_app.root_path, 'static', report.image)
            if os.path.exists(image_path):
                os.remove(image_path)
        
        db.session.delete(report)
        db.session.commit()
        flash("Report deleted successfully!", "success")
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting report: {str(e)}")
        flash("An error occurred while deleting your report.", "danger")
    
    return redirect(url_for("routes_bp.myComplaint"))

@routes_bp.route("/setting")
@login_required
def setting():
    return render_template("setting.html")