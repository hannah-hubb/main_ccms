from flask_wtf import FlaskForm
from wtforms import EmailField,PasswordField,StringField,SubmitField,SelectField,HiddenField,FileField,TextAreaField
from wtforms.validators import EqualTo,Email,Length,DataRequired
from flask_wtf.file import FileAllowed, FileRequired
class RegisterForm(FlaskForm):
    name = StringField("Name", validators=(DataRequired(), Length(min=5)))
    email = EmailField("Email",validators=(DataRequired(),Email()))
    password = PasswordField("Password" ,validators=(DataRequired(), Length(min=8)))
    confirm_password = PasswordField("Confirm Password",validators=(DataRequired(), EqualTo("password")))
    submit = SubmitField("Register")
    
class LoginForm(FlaskForm):
    email = EmailField("Email",validators=(DataRequired(),Email()))
    password = PasswordField("Password" ,validators=(DataRequired(), Length(min=8)))
    submit = SubmitField("Login")
    
class ComplaintForm(FlaskForm):
    category = SelectField(
        "Category",
        choices=[
            ("water", "Water"),
            ("light", "Light"),
            ("road", "Road"),
            ("sewage", "Sewage"),
            ("electricity", "Electricity"),
            ("other", "Other")
        ],
        validators=[DataRequired()],
    )

    description = TextAreaField(
        "Description",
        validators=[DataRequired(), Length(max=100)],
    )

    image = FileField(
        "Image",
        validators=[
            FileRequired(),
            FileAllowed(['jpg', 'jpeg', 'png'], "Images only!")
        ],
    )

    longitude = HiddenField("Longitude", validators=[DataRequired()])
    latitude = HiddenField("Latitude", validators=[DataRequired()])

    submit = SubmitField("Submit")


