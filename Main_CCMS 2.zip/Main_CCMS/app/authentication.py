
import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, current_app, jsonify

from flask_login import login_user, logout_user, login_required, current_user

from google.oauth2 import id_token
from google.auth.transport import requests as google_requests

from .models import db, User
from .forms import LoginForm, RegisterForm

auth_bp = Blueprint('auth_bp', __name__, url_prefix='/auth')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    Handles user login using traditional email and password,
    and displays debug information during the process.
    """
    if current_user.is_authenticated:
        flash('You are already logged in.', 'info')
    
        return redirect(url_for('routes_bp.home'))

    form = LoginForm()

    print(f"DEBUG: Login route accessed. Request method: {request.method}") # Debug print
    if request.method == 'POST':
        print(f"DEBUG: Form data received for login: {request.form}") # Debug print: See raw form data
        print(f"DEBUG: Is login form valid on submit? {form.validate_on_submit()}") # Debug print: Crucial check

    if form.validate_on_submit():
        print("DEBUG: login form.validate_on_submit() returned TRUE. Proceeding with login logic.") # Debug print
        email = form.email.data
        password = form.password.data

        user = User.query.filter_by(email=email).first()

        if user:
            password_check_result = user.check_password(password)

            if password_check_result:
                login_user(user)
                flash('Logged in successfully!', 'success')
                next_page = request.args.get('next')
                return redirect(next_page or url_for('routes_bp.home'))
            else:
                flash('Invalid email or password. Please try again.', 'error')
        else:
            flash('Invalid email or password. Please try again.', 'error')

    else: # This block executes if form.validate_on_submit() is FALSE for login
        print("DEBUG: login form.validate_on_submit() returned FALSE.") # Debug print
        for field, errors in form.errors.items(): # Debug print: Print validation errors for login form
            for error in errors:
                print(f"DEBUG: Login Field '{field}' error: {error}")
                flash(f"Error in {field}: {error}", 'warning') # Flash errors to frontend for user

    # Pass GOOGLE_CLIENT_ID to the template
    google_client_id = current_app.config.get('GOOGLE_CLIENT_ID')
    print(f"DEBUG: Passing google_client_id to template: {google_client_id}") # Debug print
    return render_template('login.html', form=form, google_client_id=google_client_id)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """
    Handles new user registration.
    """
    if current_user.is_authenticated:
        flash('You are already logged in.', 'info')
        return redirect(url_for('routes_bp.home')) # Changed to home for consistency

    form = RegisterForm()

    print(f"DEBUG: Register route accessed. Request method: {request.method}") # Debug print
    if request.method == 'POST': # Check if it's a POST request first
        print(f"DEBUG: Form data received: {request.form}") # Debug print: See raw form data
        print(f"DEBUG: Is form valid on submit? {form.validate_on_submit()}") # Debug print: Crucial check

    if form.validate_on_submit():
        print("DEBUG: form.validate_on_submit() returned TRUE. Proceeding with registration logic.") # Debug print
        name = form.name.data
        email = form.email.data
        password = form.password.data

        print(f"DEBUG: Form data extracted - Name: {name}, Email: {email}") # Debug print

        try:
            existing_user = User.query.filter_by(email=email).first()
            if existing_user:
                print(f"DEBUG: Email '{email}' already exists.") # Debug print
                flash('An account with this email already exists. Please log in or use Google Sign-in.', 'error')
                return render_template('register.html', form=form)

            username_base = name.replace(" ", "").lower()
            username_to_use = username_base
            i = 1
            while User.query.filter_by(name=username_to_use).first():
                print(f"DEBUG: Username '{username_to_use}' already exists. Trying next.") # Debug print
                username_to_use = f"{username_base}{i}"
                i += 1

            new_user = User(
                username=username_to_use,
                name=name,
                email=email
            )
            new_user.set_password(password)
            print(f"DEBUG: User object created: {new_user.username}, {new_user.email}") # Debug print

            db.session.add(new_user)
            db.session.commit()
            print(f"DEBUG: User '{new_user.username}' (ID: {new_user.id}) successfully added to database.") # Debug print

            flash(f'Registration for {email} successful! You can now log in.', 'success')
            return redirect(url_for('auth_bp.login'))

        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error during registration: {str(e)}", exc_info=True)
            print(f"ERROR: Exception caught during registration: {e}") # Debug print
            flash('An unexpected error occurred during registration. Please try again.', 'error')
            return render_template('register.html', form=form)
    else:
        # This block executes if form.validate_on_submit() is FALSE
        print("DEBUG: form.validate_on_submit() returned FALSE.") # Debug print
        for field, errors in form.errors.items(): # Debug print: Print validation errors
            for error in errors:
                print(f"DEBUG: Field '{field}' error: {error}")
                flash(f"Error in {field}: {error}", 'warning') # Flash errors to frontend for user

    return render_template('register.html', form=form)

@auth_bp.route('/google-signin', methods=['POST'])
def google_signin():
    id_token_jwt = request.json.get('id_token')

    if not id_token_jwt:
        current_app.logger.warning("Google Sign-In: No ID token received from frontend.")
        return jsonify({"success": False, "message": "Authentication failed: No token provided."}), 400

    try:
        google_client_id = current_app.config.get('GOOGLE_CLIENT_ID')
        if not google_client_id:
            current_app.logger.error("GOOGLE_CLIENT_ID is not configured in Flask app.")
            return jsonify({"success": False, "message": "Server configuration error."}), 500

        # Verify the Google ID token
        id_info = id_token.verify_oauth2_token(id_token_jwt, google_requests.Request(), google_client_id)

        google_id = id_info['sub'] # Unique Google user ID
        email = id_info['email']
        name = id_info.get('name', email.split('@')[0]) # Use name from Google, or part of email

        current_app.logger.info(f"Google Sign-In: Verified token for email: {email}, Google ID: {google_id}")

        # Try to find an existing user by their Google ID first
        user = User.query.filter_by(google_id=google_id).first()

        if user:
            current_app.logger.info(f"Google Sign-In: Found existing user {email} by Google ID. Logging in.")
            # Update user info if it has changed in Google (e.g., email address)
            if user.email != email:
                user.email = email
            if user.name != name:
                user.name = name
            db.session.commit()
        else:
            # User not found by Google ID, try by email (in case they previously registered traditionally)
            user = User.query.filter_by(email=email).first()
            if user:
                current_app.logger.info(f"Google Sign-In: Found existing user {email} by email, linking Google ID.")
                user.google_id = google_id # Link the Google ID to the existing account
                if user.name != name:
                    user.name = name
                db.session.commit()
                flash('Your existing account has been linked with Google for easier sign-in!', 'info')
            else:
                current_app.logger.info(f"Google Sign-In: Creating new user for email: {email}.")
                
                # Generate a unique username if not already existing
                username_base = name.replace(" ", "").lower() if name else email.split('@')[0]
                username_to_use = username_base
                i = 1
                while User.query.filter_by(username=username_to_use).first():
                    username_to_use = f"{username_base}{i}"
                    i += 1

                new_user = User(username=username_to_use, email=email, google_id=google_id, name=name)
                db.session.add(new_user)
                db.session.commit()
                user = new_user
                flash('Account created successfully via Google!', 'success')

        login_user(user) # Log the user in
        current_app.logger.info(f"User {user.email} logged in via Google successfully.")

        # Return success and redirect URL to the frontend
        return jsonify({"success": True, "message": "Sign-in successful", "redirect_url": url_for('routes_bp.home')}), 200 # Changed to home

    except ValueError as e:
        current_app.logger.error(f"Google ID token verification failed: {e}", exc_info=True)
        return jsonify({"success": False, "message": "Authentication failed: Invalid Google token or configuration."}), 401
    except Exception as e:
        db.session.rollback() # Rollback in case of any database error
        current_app.logger.error(f"An unexpected error occurred during Google sign-in process: {e}", exc_info=True)
        return jsonify({"success": False, "message": "Internal server error during Google sign-in. Please try again later."}), 500

@auth_bp.route('/logout')
@login_required
def logout():
    """
    Logs out the current user and redirects to the login page.
    """
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth_bp.login'))