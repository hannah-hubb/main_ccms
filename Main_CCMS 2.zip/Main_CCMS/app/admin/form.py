
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField,FileField,TextAreaField,SelectField,PasswordField,BooleanField
from wtforms.validators import DataRequired, Length,EqualTo,Email

class NewsForm(FlaskForm):
    title = StringField('Title', validators=[
        DataRequired(),
        Length(min=2, max=50, message='Title must be between 2 and 50 characters')
    ])
    
    image = FileField('News Image', validators=[DataRequired()])
    
    category = SelectField('Category', choices=[
            ("water", "Water"),
            ("light", "Light"),
            ("road", "Road"),
            ("sewage", "Sewage"),
            ("other", "Other")
    ], validators=[DataRequired()])
    
    description = TextAreaField('Description', validators=[
        DataRequired(),
        Length(min=10, max=100, message='Description must be between 10 and 100 characters')
    ])
    
    submit = SubmitField('Submit')

class AdminRegistrationForm(FlaskForm):
    name = StringField('Full Name', validators=[
        DataRequired(),
        Length(min=2, max=50)
    ])
    
    email = StringField('Email', validators=[
        DataRequired(),
        Email(),
        Length(max=100)
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=8, max=100)
    ])
    
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    
    category = SelectField('Admin Category', choices=[
            ("water", "Water"),
            ("light", "Light"),
            ("road", "Road"),
            ("sewage", "Sewage"),
            ("other", "Other")
    ], validators=[DataRequired()])
    
    subcity = SelectField('Subcity/District', choices=[
        ('bole', 'Bole'),
        ('north', 'North District'),
        ('south', 'South District'),
        ('east', 'East District'),
        ('west', 'West District')
    ], validators=[DataRequired()])
    
    submit = SubmitField('Create Admin Account')


class AdminLoginForm(FlaskForm):
    email = StringField('Email', validators=[
        DataRequired(),
        Email()
    ])
    password = PasswordField('Password', validators=[
        DataRequired()
    ])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Login')