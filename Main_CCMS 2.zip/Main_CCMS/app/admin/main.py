from flask import Blueprint, render_template, redirect, url_for, flash, current_app,request,jsonify
from app.models import db, News,User,Report
from flask_login import current_user,login_required
from .form import NewsForm
from werkzeug.utils import secure_filename
import os
from werkzeug.security import generate_password_hash
from datetime import datetime

admin_bp = Blueprint("admin_bp", __name__)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg', 'gif'}

@admin_bp.route('/ccms/admin/add-news', methods=['GET', 'POST'])
def add_news():
    form = NewsForm()
    if form.validate_on_submit():
        
        image = form.image.data
        if image and allowed_file(image.filename):
            filename = secure_filename(image.filename)
            upload_folder = os.path.join(current_app.root_path, 'static', 'uploads')
            os.makedirs(upload_folder, exist_ok=True)
            
            image_path = os.path.join(upload_folder, filename)
            image.save(image_path)
        else:
            flash('Invalid image file. Allowed formats: png, jpg, jpeg, gif', 'danger')
            return render_template('admin/add_news.html', form=form)
        
        
        new_news = News(
            title=form.title.data,
            image=filename,  # Store only the filename
            category=form.category.data,
            description=form.description.data,
            created_at=datetime.utcnow()
        )
        
        try:
            db.session.add(new_news)
            db.session.commit()
            flash('News added successfully!', 'success')
            return redirect(url_for('admin_bp.news_list'))  # Redirect to news list
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Error adding news: {str(e)}")
            flash('An error occurred while adding the news.', 'danger')
    
    return render_template('admin/add_news.html', form=form)



@admin_bp.route('/ccms/news/<int:news_id>')
def news_detail(news_id):
    news = News.query.get_or_404(news_id)
    return render_template('newsdetail.html', news=news)



@admin_bp.route('/ccms/admin/users', methods=['GET'])
@login_required
def manage_users():
    """View and manage all users"""
    if not current_user.is_superadmin():
        flash('Unauthorized access', 'danger')
        return redirect(url_for('routes_bp.home'))
    
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/dashboard.html', users=users)

@admin_bp.route('/ccms/admin/users/<int:user_id>/delete', methods=['POST'])
@login_required
def delete_user(user_id):
    if not current_user.is_superadmin():
        flash('Unauthorized access', 'danger')
        return redirect(url_for('routes_bp.home'))

    user = User.query.get_or_404(user_id)

    if user.id == current_user.id:
        flash('You cannot delete your own account', 'warning')
        return redirect(url_for('admin_bp.manage_users'))

    try:

        db.session.delete(user)
        db.session.commit()
        flash(f'User {user.username} and all their reports have been deleted', 'success')
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error deleting user {user_id}: {str(e)}")
        flash('Error deleting user - please try again', 'danger')
    
    return redirect(url_for('admin_bp.manage_users'))


@admin_bp.route('/admin/promote/<int:user_id>', methods=['POST'])
@login_required
def promote_user(user_id):
    
    if not current_user.is_superadmin():
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if user.is_admin():
        return jsonify({'success': False, 'message': 'User is already admin'})
    
    try:
        user.role = 'admin'
        user.category = data.get('category')
        user.subcity = data.get('subcity')
        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'{user.name} promoted to admin',
            'user': {
                'id': user.id,
                'name': user.name,
                'role': user.role,
                'category': user.category
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/admin/demote/<int:user_id>', methods=['POST'])
@login_required
def demote_user(user_id):
    """Demote admin to regular user"""
    if not current_user.is_superadmin():
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    user = User.query.get_or_404(user_id)
    
    if not user.is_admin():
        return jsonify({'success': False, 'message': 'User is not admin'})
    
    if user.is_superadmin():
        return jsonify({'success': False, 'message': 'Cannot demote superadmin'})
    
    try:
        user.role = 'user'
        user.category = None
        user.subcity = None
        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'{user.name} demoted to regular user',
            'user': {
                'id': user.id,
                'name': user.name,
                'role': user.role
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@admin_bp.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_user(user_id):
    """Edit user details"""
    if not current_user.is_superadmin():
        flash('Unauthorized access', 'danger')
        return redirect(url_for('admin.dashboard'))
    
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        try:
            user.name = request.form.get('name', user.name)
            user.email = request.form.get('email', user.email)
            user.phone = request.form.get('phone', user.phone)
            
            if user.is_admin():
                user.category = request.form.get('category', user.category)
                user.subcity = request.form.get('subcity', user.subcity)
            
            db.session.commit()
            flash('User updated successfully', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating user: {str(e)}', 'danger')
        
        return redirect(url_for('admin.manage_users'))
    
    return render_template('admin/edit_user.html', user=user)

@admin_bp.route('/admin/manage-privileges', methods=['POST'])
@login_required
def manage_privileges():
    if not current_user.is_superadmin():
        flash('Unauthorized access', 'danger')
        return redirect(url_for('admin.dashboard'))

    user_id = request.form.get('user_id')
    action = request.form.get('action')
    category = request.form.get('category')
    
    user = User.query.get_or_404(user_id)
    
    if action == 'promote':
        if user.is_admin():
            flash('User is already an admin', 'warning')
        else:
            user.role = 'admin'
            user.category = category
            user.subcity = request.form.get('subcity', 'downtown')  # Default value
            db.session.commit()
            flash(f'{user.name} has been promoted to admin', 'success')
    elif action == 'demote':
        if not user.is_admin():
            flash('User is not an admin', 'warning')
        elif user.is_superadmin():
            flash('Cannot demote superadmin', 'danger')
        else:
            user.role = 'user'
            user.category = None
            user.subcity = None
            db.session.commit()
            flash(f'{user.name} has been demoted to regular user', 'success')
    
    return redirect(url_for('admin_bp.manage_users'))



@admin_bp.route('/ccms/admin/reports')
@login_required
def admin_reports():
    # Enhanced authorization check
    if not isinstance(current_user, User) or not current_user.is_admin:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('main.index'))
    
    # Get filter parameter from query string
    status_filter = request.args.get('status', 'all')
    
    # Base query
    query = Report.query.filter_by(category=current_user.category)
    
    # Apply status filter if specified
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    reports = query.order_by(Report.createdAt.desc()).paginate(
        page=page, 
        per_page=per_page,
        error_out=False
    )
    
    # Get stats for dashboard cards
    all_reports = query.all()
    report_stats = {
        'total': len(all_reports),
        'ongoing': len([r for r in all_reports if r.status == 'ongoing']),
        'in_progress': len([r for r in all_reports if r.status == 'in_progress']),
        'resolved': len([r for r in all_reports if r.status == 'resolved'])
    }
    
    return render_template('admin/admin_dashboard.html',
                         reports=reports.items,
                         pagination=reports,
                         stats=report_stats,
                         current_filter=status_filter,
                         admin_category=current_user.category.capitalize())


@admin_bp.route('/ccms/admin/reports/<int:report_id>/delete', methods=['POST'])
@login_required
def delete_report(report_id):
    if not isinstance(current_user, User) or not current_user.is_admin:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('main.index'))
    
    report = Report.query.get_or_404(report_id)
    db.session.delete(report)
    db.session.commit()
    
    flash('Report deleted successfully', 'success')
    return redirect(url_for('admin_bp.admin_reports'))


@admin_bp.route('/ccms/admin/reports/<int:report_id>/update-status', methods=['POST'])
@login_required
def update_report_status(report_id):
    if not isinstance(current_user, User) or not current_user.is_admin:
        flash('Unauthorized access', 'danger')
        return redirect(url_for('main.index'))
    
    report = Report.query.get_or_404(report_id)
    new_status = request.form.get('status')
    
    if new_status not in ['ongoing', 'in_progress', 'resolved']:
        flash('Invalid status', 'danger')
        return redirect(url_for('admin_bp.admin_reports'))
    
    report.status = new_status
    db.session.commit()
    
    flash('Report status updated successfully', 'success')
    return redirect(url_for('admin_bp.admin_reports'))



# For super Admins
@admin_bp.route('/ccms/admin/complaints')
@login_required
def manage_complaints():
    complaints = Report.query.order_by(Report.createdAt.desc()).all()
    return render_template('admin/manage_post.html', complaints=complaints)

@admin_bp.route('/admin/complaint/<int:complaint_id>/delete', methods=['POST'])
@login_required
def delete_complaint(complaint_id):
    complaint = Report.query.get_or_404(complaint_id)
    db.session.delete(complaint)
    db.session.commit()
    flash('Complaint deleted successfully', 'success')
    return redirect(url_for('admin_bp.manage_complaints'))

@admin_bp.route('/ccms/admin/manage-news')
@login_required
def manage_news():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    news_items = News.query.order_by(News.created_at.desc()).paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
    return render_template('admin/manage_news.html', news_items=news_items)



@admin_bp.route('/admin/news/<int:news_id>/edit', methods=['GET', 'POST'])
@login_required

def edit_news(news_id):
    news = News.query.get_or_404(news_id)
    form = NewsForm(obj=news)
    if form.validate_on_submit():
        news.title = form.title.data
        news.content = form.content.data
        news.is_published = form.is_published.data
        news.last_updated = datetime.utcnow()
        db.session.commit()
        flash('News article updated successfully!', 'success')
        return redirect(url_for('admin.manage_news'))
    return render_template('admin/news_form.html', form=form, action='Edit', news=news)



@admin_bp.route('/admin/news/<int:news_id>/delete', methods=['POST'])
@login_required

def delete_news(news_id):
    news = News.query.get_or_404(news_id)
    db.session.delete(news)
    db.session.commit()
    flash('News article deleted successfully!', 'success')
    return redirect(url_for('admin.manage_news'))