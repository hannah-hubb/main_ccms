from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash,check_password_hash
from datetime import datetime
from flask_login import UserMixin
from app import db

from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    phone = db.Column(db.String(20))  
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    reports = db.relationship('Report', back_populates='user', cascade='all, delete-orphan')
    role = db.Column(db.String(20), default='user', nullable=False)  
    is_active = db.Column(db.Boolean, default=True)
    category = db.Column(db.String(50), nullable=True)  
    subcity = db.Column(db.String(50), nullable=True)   
    permissions = db.Column(db.JSON, default=list)      
    def set_password(self, password):
        """Create hashed password."""
        self.password = generate_password_hash(password)
    def check_password(self, password):
        return check_password_hash(self.password, password)
    def is_admin(self):
        return self.role in ['admin', 'superadmin']
    def is_superadmin(self):
        return self.role == 'superadmin'
    def is_active(self):
        return self.is_active
    def get_id(self):
        return str(self.id)
    def upgrade_to_admin(self, category, subcity):
        self.role = 'admin'
        self.category = category
        self.subcity = subcity
        db.session.commit()
    def downgrade_to_user(self):
        """Remove admin privileges."""
        self.role = 'user'
        self.category = None
        self.subcity = None
        db.session.commit()
    def __repr__(self):
        return f'<User {self.name} ({self.email})>'
    
class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)  
    description = db.Column(db.String(100), nullable=False)
    createdAt = db.Column(db.DateTime, default=datetime.utcnow)
    image = db.Column(db.String, nullable=False)
    longitude = db.Column(db.String, nullable=False)
    latitude = db.Column(db.String, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String, default="ongoing", nullable=False)
    user = db.relationship('User', back_populates='reports')
    comments = db.relationship('Comment', backref='report', cascade='all, delete-orphan', lazy=True)
    likes = db.relationship('Like', backref='report', cascade='all, delete-orphan', lazy=True)


class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    report_id = db.Column(db.Integer, db.ForeignKey('report.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('likes', lazy=True))


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.String(250), nullable=False)
    createdAt = db.Column(db.DateTime, default=datetime.utcnow)
    report_id = db.Column(db.Integer, db.ForeignKey('report.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('comments', lazy=True))


class News(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(50), nullable=False) 
    image = db.Column(db.String(50), nullable=False) 
    category = db.Column(db.String(50), nullable=False) 
    description = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
