
from flask import Flask
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy 

db = SQLAlchemy() 

login_manager = LoginManager()
login_manager.login_view = 'auth_bp.login'
login_manager.login_message_category = 'info'
migrate = Migrate()

from . import models 

@login_manager.user_loader
def load_user(id):
    return models.User.query.get(int(id))

def create_app():
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///ccms.db"
    app.config["SECRET_KEY"] = "sdsdsudhsdGDFER#$RCSWR#EWEWR#R#R$#RTRT" # Consider moving to environment variable

    
    db.init_app(app)
    migrate.init_app(app, db) # Flask-Migrate needs both app and db
    login_manager.init_app(app)

    # Register blueprints
    from .routes import routes_bp
    from .authentication import auth_bp
    from .admin.main import admin_bp 
    

    app.register_blueprint(routes_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    

    return app